# License Plate Detection > 2024-01-17 2:25pm
https://universe.roboflow.com/pdi-7m704/license-plate-detection-3keht

Provided by a Roboflow user
License: CC BY 4.0

**About this Dataset**

The License Plate Detection dataset is a collection of images and annotations labeling license plates of different cars. This dataset contains the object detection portion of the original dataset with bounding boxes around the license plates.

**Origin**

This dataset was collected by Renato Mendes at [MCoutinho](https://www.mcoutinho.pt/).